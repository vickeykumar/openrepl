/* Functions that provide the mechanism to parse a syscall XML file
   and get its values.

   Copyright (C) 2009-2018 Free Software Foundation, Inc.

   This file is part of GDB.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

#include "defs.h"
#include "gdbtypes.h"
#include "xml-support.h"
#include "xml-syscall.h"
#include "gdbarch.h"

/* For the struct syscall definition.  */
#include "target.h"

#include "filenames.h"

#ifndef HAVE_LIBEXPAT

/* Dummy functions to indicate that there's no support for fetching
   syscalls information.  */

static void
syscall_warn_user (void)
{
  static int have_warned = 0;
  if (!have_warned)
    {
      have_warned = 1;
      warning (_("Can not parse XML syscalls information; XML support was "
		 "disabled at compile time."));
    }
}

void
set_xml_syscall_file_name (struct gdbarch *gdbarch, const char *name)
{
  return;
}

void
get_syscall_by_number (struct gdbarch *gdbarch,
		       int syscall_number, struct syscall *s)
{
  syscall_warn_user ();
  s->number = syscall_number;
  s->name = NULL;
}

void
get_syscall_by_name (struct gdbarch *gdbarch, const char *syscall_name,
		     struct syscall *s)
{
  syscall_warn_user ();
  s->number = UNKNOWN_SYSCALL;
  s->name = syscall_name;
}

const char **
get_syscall_names (struct gdbarch *gdbarch)
{
  syscall_warn_user ();
  return NULL;
}

struct syscall *
get_syscalls_by_group (struct gdbarch *gdbarch, const char *group)
{
  syscall_warn_user ();
  return NULL;
}

const char **
get_syscall_group_names (struct gdbarch *gdbarch)
{
  syscall_warn_user ();
  return NULL;
}

#else /* ! HAVE_LIBEXPAT */

/* Structure which describes a syscall.  */
struct syscall_desc
{
  syscall_desc (int number_, std::string name_)
  : number (number_), name (name_)
  {}

  /* The syscall number.  */

  int number;

  /* The syscall name.  */

  std::string name;
};

typedef std::unique_ptr<syscall_desc> syscall_desc_up;

/* Structure of a syscall group.  */
struct syscall_group_desc
{
  syscall_group_desc (const std::string &name_)
  : name (name_)
  {}

  /* The group name.  */

  std::string name;

  /* The syscalls that are part of the group.  This is a non-owning
     reference.  */

  std::vector<syscall_desc *> syscalls;
};

typedef std::unique_ptr<syscall_group_desc> syscall_group_desc_up;

/* Structure that represents syscalls information.  */
struct syscalls_info
{
  /* The syscalls.  */

  std::vector<syscall_desc_up> syscalls;

  /* The syscall groups.  */

  std::vector<syscall_group_desc_up> groups;

  /* Variable that will hold the last known data-directory.  This is
     useful to know whether we should re-read the XML info for the
     target.  */

  std::string my_gdb_datadir;
};

typedef std::unique_ptr<syscalls_info> syscalls_info_up;

/* Callback data for syscall information parsing.  */
struct syscall_parsing_data
{
  /* The syscalls_info we are building.  */

  struct syscalls_info *syscalls_info;
};

/* Create a new syscall group.  Return pointer to the
   syscall_group_desc structure that represents the new group.  */

static struct syscall_group_desc *
syscall_group_create_syscall_group_desc (struct syscalls_info *syscalls_info,
					 const char *group)
{
  syscall_group_desc *groupdesc = new syscall_group_desc (group);

  syscalls_info->groups.emplace_back (groupdesc);

  return groupdesc;
}

/* Add a syscall to the group.  If group doesn't exist, create it.  */

static void
syscall_group_add_syscall (struct syscalls_info *syscalls_info,
			   struct syscall_desc *syscall,
			   const char *group)
{
  /* Search for an existing group.  */
  std::vector<syscall_group_desc_up>::iterator it
    = syscalls_info->groups.begin ();

  for (; it != syscalls_info->groups.end (); it++)
    {
      if ((*it)->name == group)
	break;
    }

  syscall_group_desc *groupdesc;

  if (it != syscalls_info->groups.end ())
    groupdesc = it->get ();
  else
    {
      /* No group was found with this name.  We must create a new
	 one.  */
      groupdesc = syscall_group_create_syscall_group_desc (syscalls_info,
							   group);
    }

  groupdesc->syscalls.push_back (syscall);
}

static void
syscall_create_syscall_desc (struct syscalls_info *syscalls_info,
			     const char *name, int number,
			     char *groups)
{
  syscall_desc *sysdesc = new syscall_desc (number, name);

  syscalls_info->syscalls.emplace_back (sysdesc);

  /*  Add syscall to its groups.  */
  if (groups != NULL)
    {
      for (char *group = strtok (groups, ",");
	   group != NULL;
	   group = strtok (NULL, ","))
	syscall_group_add_syscall (syscalls_info, sysdesc, group);
    }
}

/* Handle the start of a <syscall> element.  */
static void
syscall_start_syscall (struct gdb_xml_parser *parser,
                       const struct gdb_xml_element *element,
                       void *user_data, VEC(gdb_xml_value_s) *attributes)
{
  struct syscall_parsing_data *data = (struct syscall_parsing_data *) user_data;
  struct gdb_xml_value *attrs = VEC_address (gdb_xml_value_s, attributes);
  int len, i;
  /* syscall info.  */
  char *name = NULL;
  int number = 0;
  char *groups = NULL;

  len = VEC_length (gdb_xml_value_s, attributes);

  for (i = 0; i < len; i++)
    {
      if (strcmp (attrs[i].name, "name") == 0)
        name = (char *) attrs[i].value;
      else if (strcmp (attrs[i].name, "number") == 0)
        number = * (ULONGEST *) attrs[i].value;
      else if (strcmp (attrs[i].name, "groups") == 0)
        groups = (char *) attrs[i].value;
      else
        internal_error (__FILE__, __LINE__,
                        _("Unknown attribute name '%s'."), attrs[i].name);
    }

  gdb_assert (name);
  syscall_create_syscall_desc (data->syscalls_info, name, number, groups);
}


/* The elements and attributes of an XML syscall document.  */
static const struct gdb_xml_attribute syscall_attr[] = {
  { "number", GDB_XML_AF_NONE, gdb_xml_parse_attr_ulongest, NULL },
  { "name", GDB_XML_AF_NONE, NULL, NULL },
  { "groups", GDB_XML_AF_OPTIONAL, NULL, NULL },
  { NULL, GDB_XML_AF_NONE, NULL, NULL }
};

static const struct gdb_xml_element syscalls_info_children[] = {
  { "syscall", syscall_attr, NULL,
    GDB_XML_EF_OPTIONAL | GDB_XML_EF_REPEATABLE,
    syscall_start_syscall, NULL },
  { NULL, NULL, NULL, GDB_XML_EF_NONE, NULL, NULL }
};

static const struct gdb_xml_element syselements[] = {
  { "syscalls_info", NULL, syscalls_info_children,
    GDB_XML_EF_NONE, NULL, NULL },
  { NULL, NULL, NULL, GDB_XML_EF_NONE, NULL, NULL }
};

static struct syscalls_info *
syscall_parse_xml (const char *document, xml_fetch_another fetcher,
                   void *fetcher_baton)
{
  struct syscall_parsing_data data;
  syscalls_info_up sysinfo (new syscalls_info ());

  data.syscalls_info = sysinfo.get ();

  if (gdb_xml_parse_quick (_("syscalls info"), NULL,
			   syselements, document, &data) == 0)
    {
      /* Parsed successfully.  */
      return sysinfo.release ();
    }
  else
    {
      warning (_("Could not load XML syscalls info; ignoring"));
      return NULL;
    }
}

/* Function responsible for initializing the information
   about the syscalls.  It reads the XML file and fills the
   struct syscalls_info with the values.
   
   Returns the struct syscalls_info if the file is valid, NULL otherwise.  */
static struct syscalls_info *
xml_init_syscalls_info (const char *filename)
{
  gdb::unique_xmalloc_ptr<char> full_file
    = xml_fetch_content_from_file (filename, gdb_datadir);
  if (full_file == NULL)
    return NULL;

  return syscall_parse_xml (full_file.get (),
			    xml_fetch_content_from_file,
			    (void *) ldirname (filename).c_str ());
}

/* Initializes the syscalls_info structure according to the
   architecture.  */
static void
init_syscalls_info (struct gdbarch *gdbarch)
{
  struct syscalls_info *syscalls_info = gdbarch_syscalls_info (gdbarch);
  const char *xml_syscall_file = gdbarch_xml_syscall_file (gdbarch);

  /* Should we re-read the XML info for this target?  */
  if (syscalls_info != NULL && !syscalls_info->my_gdb_datadir.empty ()
      && filename_cmp (syscalls_info->my_gdb_datadir.c_str (),
		       gdb_datadir) != 0)
    {
      /* The data-directory changed from the last time we used it.
	 It means that we have to re-read the XML info.  */
      delete syscalls_info;
      syscalls_info = NULL;
      set_gdbarch_syscalls_info (gdbarch, NULL);
    }

  /* Did we succeed at initializing this?  */
  if (syscalls_info != NULL)
    return;

  syscalls_info = xml_init_syscalls_info (xml_syscall_file);

  /* If there was some error reading the XML file, we initialize
     gdbarch->syscalls_info anyway, in order to store information
     about our attempt.  */
  if (syscalls_info == NULL)
    syscalls_info = new struct syscalls_info ();

  if (syscalls_info->syscalls.empty ())
    {
      if (xml_syscall_file != NULL)
	warning (_("Could not load the syscall XML file `%s/%s'."),
		 gdb_datadir, xml_syscall_file);
      else
	warning (_("There is no XML file to open."));

      warning (_("GDB will not be able to display "
		 "syscall names nor to verify if\n"
		 "any provided syscall numbers are valid."));
    }

  /* Saving the data-directory used to read this XML info.  */
  syscalls_info->my_gdb_datadir.assign (gdb_datadir);

  set_gdbarch_syscalls_info (gdbarch, syscalls_info);
}

/* Search for a syscall group by its name.  Return syscall_group_desc
   structure for the group if found or NULL otherwise.  */

static struct syscall_group_desc *
syscall_group_get_group_by_name (const struct syscalls_info *syscalls_info,
				 const char *group)
{
  if (syscalls_info == NULL)
    return NULL;

  if (group == NULL)
    return NULL;

  /* Search for existing group.  */
  for (const syscall_group_desc_up &groupdesc : syscalls_info->groups)
    {
      if (groupdesc->name == group)
	return groupdesc.get ();
    }

  return NULL;
}

static int
xml_get_syscall_number (struct gdbarch *gdbarch,
                        const char *syscall_name)
{
  struct syscalls_info *syscalls_info = gdbarch_syscalls_info (gdbarch);

  if (syscalls_info == NULL
      || syscall_name == NULL)
    return UNKNOWN_SYSCALL;

  for (const syscall_desc_up &sysdesc : syscalls_info->syscalls)
    if (sysdesc->name == syscall_name)
      return sysdesc->number;

  return UNKNOWN_SYSCALL;
}

static const char *
xml_get_syscall_name (struct gdbarch *gdbarch,
                      int syscall_number)
{
  struct syscalls_info *syscalls_info = gdbarch_syscalls_info (gdbarch);

  if (syscalls_info == NULL
      || syscall_number < 0)
    return NULL;

  for (const syscall_desc_up &sysdesc : syscalls_info->syscalls)
    if (sysdesc->number == syscall_number)
      return sysdesc->name.c_str ();

  return NULL;
}

static const char **
xml_list_of_syscalls (struct gdbarch *gdbarch)
{
  struct syscalls_info *syscalls_info = gdbarch_syscalls_info (gdbarch);

  if (syscalls_info == NULL)
    return NULL;

  int nsyscalls = syscalls_info->syscalls.size ();
  const char **names = XNEWVEC (const char *, nsyscalls + 1);

  int i;
  for (i = 0; i < syscalls_info->syscalls.size (); i++)
    names[i] = syscalls_info->syscalls[i]->name.c_str ();

  names[i] = NULL;

  return names;
}

/* Iterate over the syscall_group_desc element to return a list of
   syscalls that are part of the given group, terminated by an empty
   element.  If the syscall group doesn't exist, return NULL.  */

static struct syscall *
xml_list_syscalls_by_group (struct gdbarch *gdbarch, const char *group)
{
  struct syscalls_info *syscalls_info = gdbarch_syscalls_info (gdbarch);
  struct syscall_group_desc *groupdesc;
  struct syscall *syscalls = NULL;
  int nsyscalls;
  int i;

  if (syscalls_info == NULL)
    return NULL;

  groupdesc = syscall_group_get_group_by_name (syscalls_info, group);
  if (groupdesc == NULL)
    return NULL;

  nsyscalls = groupdesc->syscalls.size ();
  syscalls = (struct syscall*) xmalloc ((nsyscalls + 1)
					* sizeof (struct syscall));

  for (i = 0; i < groupdesc->syscalls.size (); i++)
    {
      syscalls[i].name = groupdesc->syscalls[i]->name.c_str ();
      syscalls[i].number = groupdesc->syscalls[i]->number;
    }

  /* Add final element marker.  */
  syscalls[i].name = NULL;
  syscalls[i].number = 0;

  return syscalls;
}

/* Return a NULL terminated list of syscall groups or an empty list, if
   no syscall group is available.  Return NULL, if there is no syscall
   information available.  */

static const char **
xml_list_of_groups (struct gdbarch *gdbarch)
{
  struct syscalls_info *syscalls_info = gdbarch_syscalls_info (gdbarch);
  const char **names = NULL;
  int ngroups;
  int i;

  if (syscalls_info == NULL)
    return NULL;

  ngroups = syscalls_info->groups.size ();
  names = (const char**) xmalloc ((ngroups + 1) * sizeof (char *));

  for (i = 0; i < syscalls_info->groups.size (); i++)
    names[i] = syscalls_info->groups[i]->name.c_str ();

  names[i] = NULL;

  return names;
}

void
set_xml_syscall_file_name (struct gdbarch *gdbarch, const char *name)
{
  set_gdbarch_xml_syscall_file (gdbarch, name);
}

void
get_syscall_by_number (struct gdbarch *gdbarch,
		       int syscall_number, struct syscall *s)
{
  init_syscalls_info (gdbarch);

  s->number = syscall_number;
  s->name = xml_get_syscall_name (gdbarch, syscall_number);
}

void
get_syscall_by_name (struct gdbarch *gdbarch,
		     const char *syscall_name, struct syscall *s)
{
  init_syscalls_info (gdbarch);

  s->number = xml_get_syscall_number (gdbarch, syscall_name);
  s->name = syscall_name;
}

const char **
get_syscall_names (struct gdbarch *gdbarch)
{
  init_syscalls_info (gdbarch);

  return xml_list_of_syscalls (gdbarch);
}

/* See comment in xml-syscall.h.  */

struct syscall *
get_syscalls_by_group (struct gdbarch *gdbarch, const char *group)
{
  init_syscalls_info (gdbarch);

  return xml_list_syscalls_by_group (gdbarch, group);
}

/* See comment in xml-syscall.h.  */

const char **
get_syscall_group_names (struct gdbarch *gdbarch)
{
  init_syscalls_info (gdbarch);

  return xml_list_of_groups (gdbarch);
}

#endif /* ! HAVE_LIBEXPAT */
