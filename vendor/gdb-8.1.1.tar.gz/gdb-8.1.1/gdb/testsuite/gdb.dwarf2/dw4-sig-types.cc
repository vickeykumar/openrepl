
#include "dw4-sig-types.h"

myns::bar_type myset;

int
main ()
{
  foo ();

  return 0;
}
