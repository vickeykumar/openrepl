
#include <set>
using std::set;

namespace myns
{

struct bar_type
{
  set<int> foo;
};

} // myns

extern void foo ();
