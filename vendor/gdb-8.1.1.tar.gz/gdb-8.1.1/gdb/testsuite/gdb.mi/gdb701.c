struct _foo
{
  int x;
  int y;
  int z;
};

typedef struct _foo Foo;

int
main (int argc, char *argv[])
{
  Foo *foo = 0;
  return 0;
}
